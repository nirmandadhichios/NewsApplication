//
//  CategoryArticles.swift
//  CategoryArticles
//
//  Created by Nirman dadhich on 11/11/22.
//


import Foundation

struct CategoryArticles: Codable {
    
    let category: Category
    let articles: [Article]
}
